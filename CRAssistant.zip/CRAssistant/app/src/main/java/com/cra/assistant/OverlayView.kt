package com.cra.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Прозрачный слой поверх игры.
 * Зелёная точка — карта, которую играть (над слотом руки).
 * Жёлтая точка — куда её ставить.
 * Сверху — компактная сводка: эликсир, рука, HP башен, совет.
 */
class OverlayView(ctx: Context) : View(ctx) {
    private var state: GameState? = null
    private var advice: Advice? = null

    private val density = resources.displayMetrics.density
    private val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 255, 70) }
    private val yellow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 225, 0) }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 4f * density
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 13f * density
        setShadowLayer(3f * density, 0f, 0f, Color.BLACK)
    }

    fun update(s: GameState, a: Advice) {
        state = s
        advice = a
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = state ?: return
        val a = advice ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val rad = 11f * density

        // сводка сверху (область выше y=0.09, анализатор её не использует)
        var ty = 0.028f * h
        val line = 16f * density
        canvas.drawText(a.text, 8f * density, ty, text); ty += line
        if (s.inBattle) {
            val hand = s.hand.joinToString(" | ") {
                when {
                    !it.hasCard -> "-"
                    it.deckIndex == null -> "?"
                    else -> Deck.cards[it.deckIndex].name
                }
            }
            canvas.drawText("Эликсир ${String.format("%.1f", s.elixir)}  Рука: $hand", 8f * density, ty, text); ty += line
            canvas.drawText(
                "HP врага Л/П: ${pct(s.enemyLeftHp)}/${pct(s.enemyRightHp)}   мои Л/П: ${pct(s.myLeftHp)}/${pct(s.myRightHp)}   юнитов врага: ${s.enemyUnits.size}",
                8f * density, ty, text,
            )
        }

        // точки подсказки
        val slot = a.cardSlot
        if (slot != null) {
            val cx = Layout.HAND_X[slot] * w
            val cy = (Layout.CARD_TOP - 0.014f) * h
            canvas.drawCircle(cx, cy, rad, green)
            canvas.drawCircle(cx, cy, rad, outline)
        }
        val t = a.target
        if (t != null) {
            canvas.drawCircle(t.x * w, t.y * h, rad * 1.3f, yellow)
            canvas.drawCircle(t.x * w, t.y * h, rad * 1.3f, outline)
        }
    }

    private fun pct(v: Float?) = if (v == null) "100%" else "${(v * 100).toInt()}%"
}
