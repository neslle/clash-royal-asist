package com.cra.assistant

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.View
import android.view.WindowManager

/**
 * Фоновый сервис: захват экрана -> анализ кадра -> оверлей.
 * Анализ идёт только пока на переднем плане именно Clash Royale.
 */
class CaptureService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private lateinit var wm: WindowManager
    private lateinit var detector: GameDetector
    private lateinit var analyzer: FrameAnalyzer

    @Volatile private var gameActive = false
    private var lastAnalysis = 0L
    private var running = false

    private val checker = object : Runnable {
        override fun run() {
            if (!Perms.allGranted(this@CaptureService)) { stopSelf(); return }
            gameActive = detector.isClashRoyaleForeground()
            overlay?.visibility = if (gameActive) View.VISIBLE else View.INVISIBLE
            main.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // без разрешений не запускаемся
        if (!Perms.allGranted(this) || intent == null) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY

        startAsForeground()

        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("data", Intent::class.java) else intent.getParcelableExtra("data")
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        detector = GameDetector(this)
        analyzer = FrameAnalyzer(this)

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)

        @Suppress("DEPRECATION")
        val dm = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
        val capW = (dm.widthPixels * 0.6f).toInt()
        val capH = (dm.heightPixels * 0.6f).toInt()

        worker = HandlerThread("cra-capture").also { it.start() }
        val handler = Handler(worker!!.looper)
        val rd = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = rd
        display = proj.createVirtualDisplay(
            "cra", capW, capH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, handler,
        )
        rd.setOnImageAvailableListener({ onFrame(it) }, handler)

        addOverlay(dm)
        running = true
        main.post(checker)
        return START_NOT_STICKY
    }

    private fun onFrame(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (!gameActive || now - lastAnalysis < 250) return
            lastAnalysis = now

            val plane = img.planes[0]
            val bmpW = plane.rowStride / plane.pixelStride
            val h = img.height
            val bmp = Bitmap.createBitmap(bmpW, h, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(plane.buffer)
            val px = IntArray(bmpW * h)
            bmp.getPixels(px, 0, bmpW, 0, 0, bmpW, h)
            bmp.recycle()

            val state = analyzer.analyze(px, bmpW, img.width, h)
            val advice = Advisor.advise(state)
            main.post { overlay?.update(state, advice) }
        } finally {
            img.close()
        }
    }

    private fun addOverlay(dm: DisplayMetrics) {
        val v = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            dm.widthPixels, dm.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        lp.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        v.visibility = View.INVISIBLE
        wm.addView(v, lp)
        overlay = v
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cra", "CR Помощник", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cra")
            .setContentTitle("CR Помощник работает")
            .setContentText("Анализ экрана идёт только внутри Clash Royale")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacks(checker)
        runCatching { overlay?.let { wm.removeView(it) } }
        overlay = null
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        worker?.quitSafely()
        super.onDestroy()
    }
}
