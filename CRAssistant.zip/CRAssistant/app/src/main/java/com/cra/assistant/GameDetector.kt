package com.cra.assistant

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context

/**
 * Проверяет, что поверх всего сейчас именно Clash Royale (по событиям UsageStats).
 * Состояние накапливается между вызовами, поэтому долгая игра без новых событий не теряется.
 */
class GameDetector(private val ctx: Context) {
    companion object {
        const val PACKAGE = "com.supercell.clashroyale"
    }

    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private var lastTs = System.currentTimeMillis() - 24L * 3600 * 1000
    private var foreground: String? = null

    fun isClashRoyaleForeground(): Boolean {
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(lastTs, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> foreground = e.packageName
                UsageEvents.Event.ACTIVITY_PAUSED, UsageEvents.Event.ACTIVITY_STOPPED ->
                    if (foreground == e.packageName) foreground = null
            }
        }
        lastTs = now
        return foreground == PACKAGE
    }
}
