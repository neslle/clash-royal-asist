package com.cra.assistant

import android.content.Context
import android.graphics.BitmapFactory
import kotlin.math.abs
import kotlin.math.sqrt

data class PointF(val x: Float, val y: Float)

data class HandSlot(val index: Int, val hasCard: Boolean, val deckIndex: Int?)

data class GameState(
    val inBattle: Boolean,
    val elixir: Float,
    val hand: List<HandSlot>,
    /** Доля HP принцесс (0..1). null = полоска не видна (башня целая или не распознана). */
    val enemyLeftHp: Float?,
    val enemyRightHp: Float?,
    val myLeftHp: Float?,
    val myRightHp: Float?,
    /** Положения вражеских юнитов в долях экрана (по красным полоскам HP). */
    val enemyUnits: List<PointF>,
)

/**
 * Все координаты — в ДОЛЯХ экрана (0..1), откалиброваны по скриншоту 1080x2400 (Nothing CMF Phone 1).
 * Поэтому приложение само подстраивается под любое разрешение с таким же соотношением сторон (20:9).
 */
object Layout {
    const val RIVER_Y = 0.4375f

    const val ELIXIR_Y = 0.9812f
    const val ELIXIR_X0 = 0.325f
    const val ELIXIR_X1 = 0.965f

    val HAND_X = floatArrayOf(0.310f, 0.520f, 0.688f, 0.877f)
    const val CARD_HALF_W = 0.0856f
    const val CARD_TOP = 0.869f
    const val CARD_BOTTOM = 0.958f

    // x0, x1, yВерх, yНиз полоски HP
    val ENEMY_L = floatArrayOf(0.172f, 0.283f, 0.1875f, 0.1942f)
    val ENEMY_R = floatArrayOf(0.764f, 0.875f, 0.1875f, 0.1942f)
    val MY_L = floatArrayOf(0.172f, 0.283f, 0.6158f, 0.6225f)
    val MY_R = floatArrayOf(0.764f, 0.875f, 0.6158f, 0.6225f)

    // где НЕ искать красные полоски юнитов (башни противника): x0, y0, x1, y1
    val TOWER_ZONES = arrayOf(
        floatArrayOf(0.05f, 0.15f, 0.33f, 0.31f),
        floatArrayOf(0.69f, 0.15f, 0.95f, 0.31f),
        floatArrayOf(0.38f, 0.08f, 0.62f, 0.25f),
    )
}

class FrameAnalyzer(ctx: Context) {
    private val deckSigs: List<FloatArray>

    init {
        deckSigs = Deck.cards.indices.map { i ->
            val bmp = ctx.assets.open("deck/$i.png").use { BitmapFactory.decodeStream(it) }
            val arr = IntArray(bmp.width * bmp.height)
            bmp.getPixels(arr, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            val s = signature(arr, bmp.width, bmp.width, bmp.height, 0.25f, 0.20f, 0.75f, 0.60f).first
            bmp.recycle()
            s
        }
    }

    fun analyze(px: IntArray, stride: Int, w: Int, h: Int): GameState {
        val inBattle = isMagenta(at(px, stride, w, h, 0.24f, 0.98f)) &&
            isPanelBlue(at(px, stride, w, h, 0.06f, 0.93f))
        if (!inBattle) {
            return GameState(false, 0f, emptyList(), null, null, null, null, emptyList())
        }
        return GameState(
            inBattle = true,
            elixir = readElixir(px, stride, w, h),
            hand = readHand(px, stride, w, h),
            enemyLeftHp = barRatio(px, stride, w, h, Layout.ENEMY_L, true),
            enemyRightHp = barRatio(px, stride, w, h, Layout.ENEMY_R, true),
            myLeftHp = barRatio(px, stride, w, h, Layout.MY_L, false),
            myRightHp = barRatio(px, stride, w, h, Layout.MY_R, false),
            enemyUnits = findEnemyUnits(px, stride, w, h),
        )
    }

    // ---------- цвета ----------
    private fun r(c: Int) = (c shr 16) and 255
    private fun g(c: Int) = (c shr 8) and 255
    private fun b(c: Int) = c and 255

    private fun isMagenta(c: Int) = r(c) > 170 && b(c) > 170 && g(c) < 130
    private fun isPanelBlue(c: Int) = r(c) < 60 && b(c) > 100 && b(c) > g(c) + 30

    private fun at(px: IntArray, stride: Int, w: Int, h: Int, xr: Float, yr: Float): Int {
        val x = (xr * w).toInt().coerceIn(0, w - 1)
        val y = (yr * h).toInt().coerceIn(0, h - 1)
        return px[y * stride + x]
    }

    // ---------- эликсир ----------
    private fun readElixir(px: IntArray, stride: Int, w: Int, h: Int): Float {
        val y = (Layout.ELIXIR_Y * h).toInt()
        val xs = (Layout.ELIXIR_X0 * w).toInt()
        val xe = (Layout.ELIXIR_X1 * w).toInt()
        var last = -1
        for (x in xs until xe) if (isMagenta(px[y * stride + x])) last = x
        if (last < 0) return 0f
        val v = (last - xs).toFloat() / (xe - xs) * 10f
        return (Math.round(v * 10f) / 10f).coerceIn(0f, 10f)
    }

    // ---------- рука ----------
    private fun readHand(px: IntArray, stride: Int, w: Int, h: Int): List<HandSlot> {
        val cardW = Layout.CARD_HALF_W * 2
        val cardH = Layout.CARD_BOTTOM - Layout.CARD_TOP
        return Layout.HAND_X.mapIndexed { i, cx ->
            val left = cx - Layout.CARD_HALF_W
            val (sig, spread) = signature(
                px, stride, w, h,
                left + 0.25f * cardW, Layout.CARD_TOP + 0.20f * cardH,
                left + 0.75f * cardW, Layout.CARD_TOP + 0.60f * cardH,
            )
            if (spread < 25f) {
                HandSlot(i, false, null) // пустой слот — ровный синий фон
            } else {
                var best = -1
                var bestD = Float.MAX_VALUE
                deckSigs.forEachIndexed { k, ds ->
                    var d = 0f
                    for (j in sig.indices) { val t = sig[j] - ds[j]; d += t * t }
                    d /= sig.size
                    if (d < bestD) { bestD = d; best = k }
                }
                HandSlot(i, true, if (bestD < 0.5f) best else null)
            }
        }
    }

    /** Цветовая подпись области 12x12 (нормализованная) + разброс яркости до нормализации. */
    private fun signature(
        px: IntArray, stride: Int, w: Int, h: Int,
        x0: Float, y0: Float, x1: Float, y1: Float,
    ): Pair<FloatArray, Float> {
        val n = 12
        val out = FloatArray(n * n * 3)
        var idx = 0
        for (j in 0 until n) for (i in 0 until n) {
            var sr = 0f; var sg = 0f; var sb = 0f
            for (bb in 0 until 3) for (aa in 0 until 3) {
                val xr = x0 + (i + (aa + 0.5f) / 3f) * (x1 - x0) / n
                val yr = y0 + (j + (bb + 0.5f) / 3f) * (y1 - y0) / n
                val c = px[(yr * h).toInt().coerceIn(0, h - 1) * stride + (xr * w).toInt().coerceIn(0, w - 1)]
                sr += r(c); sg += g(c); sb += b(c)
            }
            out[idx++] = sr / 9f; out[idx++] = sg / 9f; out[idx++] = sb / 9f
        }
        val mean = out.average().toFloat()
        var v = 0f
        for (q in out) v += (q - mean) * (q - mean)
        val sd = sqrt(v / out.size)
        for (k in out.indices) out[k] = (out[k] - mean) / (sd + 1e-6f)
        return out to sd
    }

    // ---------- HP башен ----------
    private fun barRatio(px: IntArray, stride: Int, w: Int, h: Int, bar: FloatArray, enemy: Boolean): Float? {
        val xs = (bar[0] * w).toInt()
        val xe = (bar[1] * w).toInt()
        var fill = 0
        var track = 0
        for (yr in floatArrayOf(bar[2], bar[3])) {
            val y = (yr * h).toInt().coerceIn(0, h - 1)
            for (x in xs until xe) {
                val c = px[y * stride + x]
                val isFill = if (enemy) {
                    r(c) > 190 && g(c) < 135 && b(c) < 175 && r(c) - g(c) > 90
                } else {
                    b(c) > 170 && r(c) < 100 && g(c) > 90 && b(c) - r(c) > 90
                }
                if (isFill) fill++
                else if (r(c) < 110 && g(c) < 110 && b(c) < 160) track++
            }
        }
        val total = fill + track
        if (total < (xe - xs)) return null // полоски не видно
        return fill.toFloat() / total
    }

    // ---------- вражеские юниты ----------
    private fun isUnitRed(c: Int) = r(c) > 190 && g(c) < 90 && b(c) < 130 && r(c) - g(c) > 110

    private fun inTowerZone(xr: Float, yr: Float): Boolean =
        Layout.TOWER_ZONES.any { xr >= it[0] && yr >= it[1] && xr <= it[2] && yr <= it[3] }

    private fun findEnemyUnits(px: IntArray, stride: Int, w: Int, h: Int): List<PointF> {
        val step = 2
        val gw = w / step
        val gh = h / step
        val mask = BooleanArray(gw * gh)
        val gy0 = (0.11f * h).toInt() / step
        val gy1 = (0.80f * h).toInt() / step
        for (gy in gy0 until gy1) for (gx in 0 until gw) {
            val c = px[gy * step * stride + gx * step]
            if (isUnitRed(c) && !inTowerZone(gx * step / w.toFloat(), gy * step / h.toFloat())) {
                mask[gy * gw + gx] = true
            }
        }
        val res = ArrayList<PointF>()
        val seen = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        for (start in mask.indices) {
            if (!mask[start] || seen[start]) continue
            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var minX = Int.MAX_VALUE; var maxX = -1; var minY = Int.MAX_VALUE; var maxY = -1; var cnt = 0
            while (sp > 0) {
                val cur = stack[--sp]
                val cx = cur % gw
                val cy = cur / gw
                cnt++
                if (cx < minX) minX = cx
                if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy
                if (cy > maxY) maxY = cy
                if (cx > 0 && mask[cur - 1] && !seen[cur - 1]) { seen[cur - 1] = true; stack[sp++] = cur - 1 }
                if (cx < gw - 1 && mask[cur + 1] && !seen[cur + 1]) { seen[cur + 1] = true; stack[sp++] = cur + 1 }
                if (cy > 0 && mask[cur - gw] && !seen[cur - gw]) { seen[cur - gw] = true; stack[sp++] = cur - gw }
                if (cy < gh - 1 && mask[cur + gw] && !seen[cur + gw]) { seen[cur + gw] = true; stack[sp++] = cur + gw }
            }
            val wpx = (maxX - minX + 1) * step
            val hpx = (maxY - minY + 1) * step
            val wr = wpx.toFloat() / w
            val hr = hpx.toFloat() / h
            val density = cnt.toFloat() * step * step / (wpx * hpx)
            // тонкая горизонтальная полоска: это HP-бар юнита, а не точка/башня
            if (wr in 0.02f..0.12f && hr in 0.0015f..0.014f && wpx >= 2.5f * hpx && density > 0.5f) {
                val xr = (minX + maxX) / 2f * step / w
                val yr = minY * step / h.toFloat() + 0.02f // сам юнит чуть ниже полоски
                res.add(PointF(xr, yr))
            }
        }
        return res
    }
}
