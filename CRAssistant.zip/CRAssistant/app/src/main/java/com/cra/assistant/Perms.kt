package com.cra.assistant

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings

/** Проверка разрешений. Без любого из них приложение не запускается. */
object Perms {
    fun overlay(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun usage(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun notifications(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Всё, кроме захвата экрана (его выдаёт системный диалог при каждом запуске). */
    fun allGranted(c: Context): Boolean = overlay(c) && usage(c) && notifications(c)
}
