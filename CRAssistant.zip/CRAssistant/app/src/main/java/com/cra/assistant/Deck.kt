package com.cra.assistant

enum class Role { WINCON, MELEE_SPLASH, MELEE_DPS, RANGED_SPLASH, AIR_SWARM, GROUND_SWARM, SPELL }

data class Card(val name: String, val cost: Int, val role: Role)

/**
 * Колода игрока. Порядок = файлы assets/deck/0.png ... 7.png
 * (иконки вырезаны из вашего скриншота колоды).
 * Если какая-то карта определена неверно (помечены "?") — поправьте имя/роль здесь.
 * Чтобы сменить колоду: замените PNG в assets/deck и этот список.
 */
object Deck {
    val cards = listOf(
        Card("Валькирия", 4, Role.MELEE_SPLASH),
        Card("Берсерк", 2, Role.MELEE_DPS),
        Card("Тёмный принц?", 4, Role.MELEE_SPLASH),
        Card("Заклинание?", 3, Role.SPELL),
        Card("Миньоны", 3, Role.AIR_SWARM),
        Card("Гоблины", 3, Role.GROUND_SWARM),
        Card("Принцесса", 3, Role.RANGED_SPLASH),
        Card("Всадник на кабане", 4, Role.WINCON),
    )
}

/**
 * Таблица "карта противника -> какие роли её контрят".
 * Составлена по общеизвестным контрам (RoyaleAPI / вики), не парсилась автоматически.
 * Используется, когда id карты противника известен (ручной ввод / будущая модель).
 */
object CounterDb {
    val counters: Map<String, List<Role>> = mapOf(
        "Гигант" to listOf(Role.MELEE_DPS, Role.AIR_SWARM, Role.GROUND_SWARM),
        "Королевский гигант" to listOf(Role.AIR_SWARM, Role.MELEE_DPS),
        "Голем" to listOf(Role.AIR_SWARM, Role.MELEE_DPS),
        "Всадник на кабане" to listOf(Role.MELEE_SPLASH, Role.GROUND_SWARM, Role.MELEE_DPS),
        "Таран" to listOf(Role.MELEE_DPS, Role.MELEE_SPLASH),
        "Воздушный шар" to listOf(Role.AIR_SWARM, Role.RANGED_SPLASH),
        "Лавовая гончая" to listOf(Role.AIR_SWARM, Role.RANGED_SPLASH),
        "Дракончик" to listOf(Role.AIR_SWARM, Role.RANGED_SPLASH),
        "Миньоны" to listOf(Role.RANGED_SPLASH, Role.SPELL),
        "Орда миньонов" to listOf(Role.RANGED_SPLASH, Role.SPELL),
        "Скелеты" to listOf(Role.MELEE_SPLASH, Role.SPELL),
        "Армия скелетов" to listOf(Role.MELEE_SPLASH, Role.SPELL, Role.RANGED_SPLASH),
        "Гоблины" to listOf(Role.MELEE_SPLASH, Role.SPELL, Role.RANGED_SPLASH),
        "Принцесса" to listOf(Role.SPELL),
        "Рыцарь" to listOf(Role.MELEE_SPLASH, Role.MELEE_DPS),
        "Валькирия" to listOf(Role.MELEE_DPS, Role.AIR_SWARM),
        "Мини-ПЕККА" to listOf(Role.GROUND_SWARM, Role.MELEE_SPLASH),
        "ПЕККА" to listOf(Role.GROUND_SWARM, Role.AIR_SWARM),
        "Мегарыцарь" to listOf(Role.MELEE_DPS, Role.AIR_SWARM),
        "Принц" to listOf(Role.GROUND_SWARM, Role.MELEE_DPS),
        "Тёмный принц" to listOf(Role.GROUND_SWARM, Role.MELEE_DPS),
        "Колдун" to listOf(Role.SPELL, Role.WINCON),
        "Ведьма" to listOf(Role.MELEE_SPLASH, Role.SPELL),
        "Мушкетёр" to listOf(Role.WINCON, Role.SPELL),
    )
}
