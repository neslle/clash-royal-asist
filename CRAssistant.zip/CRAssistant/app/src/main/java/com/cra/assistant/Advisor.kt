package com.cra.assistant

import kotlin.math.abs

data class Advice(
    val text: String,
    /** Слот руки (0..3), карту из которого надо играть — рисуем на нём зелёную точку. */
    val cardSlot: Int?,
    /** Куда ставить (доли экрана) — рисуем жёлтую точку. */
    val target: PointF?,
)

object Advisor {
    private const val LANE_L = 0.204f
    private const val LANE_R = 0.790f

    fun advise(s: GameState, enemyNames: List<String> = emptyList()): Advice {
        if (!s.inBattle) return Advice("Жду начала матча…", null, null)

        val playable = s.hand.filter {
            it.hasCard && it.deckIndex != null && Deck.cards[it.deckIndex].cost <= s.elixir + 0.05f
        }
        val warn = lowHpWarning(s)

        // --- защита: вражеские юниты на нашей половине ---
        val threats = s.enemyUnits.filter { it.y > Layout.RIVER_Y + 0.03f }
        if (threats.isNotEmpty()) {
            val front = threats.maxByOrNull { it.y }!!
            val left = front.x < 0.5f
            val lane = if (left) "левой" else "правой"
            val near = threats.count { abs(it.x - front.x) < 0.14f && abs(it.y - front.y) < 0.12f }
            val swarm = near >= 3

            val wanted: List<Role> = enemyNames.firstNotNullOfOrNull { CounterDb.counters[it] }
                ?: if (swarm) listOf(Role.MELEE_SPLASH, Role.RANGED_SPLASH, Role.SPELL)
                else listOf(Role.MELEE_DPS, Role.AIR_SWARM, Role.GROUND_SWARM, Role.MELEE_SPLASH, Role.RANGED_SPLASH)

            val pick = pickByRole(playable, wanted) ?: playable.minByOrNull { Deck.cards[it.deckIndex!!].cost }
                ?: return Advice("Атака на $lane линии, эликсира мало (${fmt(s.elixir)}) — держись башней$warn", null, null)

            val card = Deck.cards[pick.deckIndex!!]
            val target = defendPoint(card.role, left, front)
            val kind = if (swarm) "толпа" else "одиночная цель"
            return Advice("Защита ($lane линия, $kind): ${card.name}$warn", pick.index, target)
        }

        // --- атака ---
        if (s.elixir < 6f) return Advice("Копи эликсир: ${fmt(s.elixir)}/10$warn", null, null)

        val lHp = s.enemyLeftHp ?: 1f
        val rHp = s.enemyRightHp ?: 1f
        val left = lHp <= rHp
        val laneX = if (left) LANE_L else LANE_R
        val lane = if (left) "левая" else "правая"

        val attackers = playable.filter { Deck.cards[it.deckIndex!!].role != Role.SPELL }
        val pick = pickByRole(attackers, listOf(Role.WINCON, Role.MELEE_SPLASH, Role.MELEE_DPS))
            ?: attackers.firstOrNull()
            ?: return Advice("Нет подходящей карты для атаки$warn", null, null)

        val card = Deck.cards[pick.deckIndex!!]
        val target = if (card.role == Role.WINCON) PointF(laneX, 0.47f) else PointF(laneX, 0.60f)
        return Advice("Атака: $lane линия (слабее башня) — ${card.name}$warn", pick.index, target)
    }

    private fun pickByRole(slots: List<HandSlot>, wanted: List<Role>): HandSlot? {
        for (role in wanted) {
            val m = slots.filter { Deck.cards[it.deckIndex!!].role == role }
                .minByOrNull { Deck.cards[it.deckIndex!!].cost }
            if (m != null) return m
        }
        return null
    }

    private fun defendPoint(role: Role, left: Boolean, front: PointF): PointF = when (role) {
        Role.SPELL -> PointF(front.x, front.y)
        Role.RANGED_SPLASH, Role.AIR_SWARM -> PointF(if (left) 0.30f else 0.70f, 0.66f)
        Role.GROUND_SWARM -> PointF(if (left) 0.22f else 0.78f, 0.60f)
        else -> PointF(if (left) 0.22f else 0.78f, 0.58f)
    }

    private fun lowHpWarning(s: GameState): String {
        val l = s.myLeftHp
        val r = s.myRightHp
        return when {
            l != null && l < 0.35f -> " ⚠ левая башня слаба"
            r != null && r < 0.35f -> " ⚠ правая башня слаба"
            else -> ""
        }
    }

    private fun fmt(v: Float) = String.format("%.1f", v)
}
