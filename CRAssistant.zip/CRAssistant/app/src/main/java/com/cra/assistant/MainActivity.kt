package com.cra.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Экран-«ворота»: пока не выданы все разрешения, кнопка запуска заблокирована.
 * При возврате из настроек (onResume) статусы перепроверяются.
 */
class MainActivity : Activity() {
    private lateinit var overlayStatus: TextView
    private lateinit var usageStatus: TextView
    private lateinit var notifStatus: TextView
    private lateinit var startBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(title("CR Помощник"))
        root.addView(info("Для работы нужны все разрешения ниже. Без них приложение не запустится."))

        overlayStatus = status()
        root.addView(overlayStatus)
        root.addView(btn("Разрешить показ поверх других окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        usageStatus = status()
        root.addView(usageStatus)
        root.addView(btn("Дать доступ к статистике использования") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })

        notifStatus = status()
        root.addView(notifStatus)
        root.addView(btn("Разрешить уведомления") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        })

        root.addView(info("Захват экрана система спросит при нажатии «Запустить»."))
        startBtn = btn("Запустить") {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), 100)
        }
        root.addView(startBtn)
        root.addView(btn("Остановить") { stopService(Intent(this, CaptureService::class.java)) })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Без захвата экрана приложение не работает", Toast.LENGTH_LONG).show()
            return
        }
        if (!Perms.allGranted(this)) { refresh(); return }
        val svc = Intent(this, CaptureService::class.java)
            .putExtra("code", resultCode)
            .putExtra("data", data)
        startForegroundService(svc)
        Toast.makeText(this, "Запущено. Откройте Clash Royale и зайдите в матч", Toast.LENGTH_LONG).show()
    }

    private fun refresh() {
        mark(overlayStatus, "Поверх других окон", Perms.overlay(this))
        mark(usageStatus, "Доступ к статистике использования", Perms.usage(this))
        mark(notifStatus, "Уведомления", Perms.notifications(this))
        startBtn.isEnabled = Perms.allGranted(this)
    }

    private fun mark(tv: TextView, name: String, ok: Boolean) {
        tv.text = (if (ok) "✅ " else "❌ ") + name
        tv.setTextColor(if (ok) Color.rgb(0, 130, 0) else Color.rgb(190, 0, 0))
    }

    private fun title(t: String) = TextView(this).apply { text = t; textSize = 26f; setTextColor(Color.BLACK) }
    private fun info(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, 12, 0, 12) }
    private fun status() = TextView(this).apply { textSize = 16f; setPadding(0, 24, 0, 4); gravity = Gravity.START }
    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { onClick() }
    }
}
